---
name: Skyline IoT Management
colors:
  surface: '#f6faff'
  surface-dim: '#d6dae0'
  surface-bright: '#f6faff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f4fa'
  surface-container: '#eaeef4'
  surface-container-high: '#e4e8ee'
  surface-container-highest: '#dee3e9'
  on-surface: '#171c20'
  on-surface-variant: '#3e4850'
  inverse-surface: '#2c3135'
  inverse-on-surface: '#edf1f7'
  outline: '#6e7881'
  outline-variant: '#bec8d2'
  surface-tint: '#006591'
  primary: '#006591'
  on-primary: '#ffffff'
  primary-container: '#0ea5e9'
  on-primary-container: '#003751'
  inverse-primary: '#89ceff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#8a5100'
  on-tertiary: '#ffffff'
  tertiary-container: '#de8712'
  on-tertiary-container: '#4d2b00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c9e6ff'
  primary-fixed-dim: '#89ceff'
  on-primary-fixed: '#001e2f'
  on-primary-fixed-variant: '#004c6e'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdcbd'
  tertiary-fixed-dim: '#ffb86e'
  on-tertiary-fixed: '#2c1600'
  on-tertiary-fixed-variant: '#693c00'
  background: '#f6faff'
  on-background: '#171c20'
  surface-variant: '#dee3e9'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.3'
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.4'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  data-point:
    fontFamily: JetBrains Mono
    fontSize: 15px
    fontWeight: '500'
    lineHeight: '1'
  data-lg:
    fontFamily: JetBrains Mono
    fontSize: 28px
    fontWeight: '400'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  container-margin: 32px
  gutter: 20px
---

## Brand & Style

The design system is rooted in **Modern Minimalism**, specifically tailored for the industrial-tech crossover of IoT waste management. The objective is to strip away the "gritty" nature of waste logistics and replace it with a high-clarity, optimistic interface that feels as clean as the desired environmental outcome.

By utilizing generous whitespace and a "light-and-airy" aesthetic, the system reduces the cognitive load associated with monitoring high-density sensor data. The brand personality is efficient, transparent, and forward-thinking. It avoids the heavy gradients of traditional industrial software in favor of flat surfaces, subtle depth through elevation, and high-precision typography.

## Colors

The palette is designed to maximize legibility and focus. 
- **Primary Surface:** Pure white is used for the main workspace to keep the feel "sterile" and high-contrast. The subtle gray (#F8FAFC) is reserved for sidebars or background groupings to create logical separation.
- **Brand Action:** Vibrant Sky Blue is the primary driver for interaction. It is used sparingly for buttons, active toggle states, and progress bars to ensure "actionability" is never ambiguous.
- **Semantic Accents:** Success, Warning, and Critical states use soft-tinted versions of emerald, amber, and rose. These colors should be used for status pips, small badges, and data-line indicators to alert users to bin levels or maintenance needs without causing visual alarm.

## Typography

The system utilizes a tri-font approach to categorize information type:
1. **Space Grotesk** is used for structural headings. Its geometric, slightly technical character reinforces the "smart city" innovation aspect.
2. **Inter** handles all functional UI text and body copy. It is selected for its exceptional readability at small sizes on low-resolution field tablets.
3. **JetBrains Mono** is strictly reserved for sensor data, timestamps, and coordinates. This distinguishes "static labels" from "dynamic data," allowing the operator's eye to skip directly to the numbers.

**Scaling Note:** For mobile views, `display-lg` should scale down to 28px. All `data-point` weights should stay at 500 or below to prevent the monospaced characters from feeling too "heavy" against the clean UI.

## Layout & Spacing

This design system employs a **Fluid Grid** with fixed-width margins for desktop. 
- **Desktop:** 12-column grid with 24px gutters. Content should be housed in "Cards" that typically span 3, 4, 6, or 12 columns.
- **Tablet:** 8-column grid with 16px gutters.
- **Mobile:** 4-column grid with 16px margins.

The spacing rhythm is strictly 4px-based. Use `xl` (48px) for separating major dashboard sections to maintain the "airy" feel. Horizontal padding within cards should always be one step larger than vertical padding (e.g., 24px sides, 16px top/bottom) to emphasize the horizontal flow of data across the screen.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Ambient Shadows** rather than heavy borders.
- **Level 0 (Canvas):** Pure white (#FFFFFF). Used for the overall background.
- **Level 1 (Cards/Surface):** Very subtle light gray (#F8FAFC) or White with a thin #E2E8F0 border.
- **Shadows:** Use a single, soft shadow style for interactive elements: `0px 4px 12px rgba(30, 41, 59, 0.05)`. This creates a lifted effect that feels light and modern.
- **Active State:** When an element is selected, it should transition from a subtle border to a 2px primary sky-blue border, rather than increasing shadow depth.

## Shapes

The shape language is defined by **Rounded (12px - 16px)** corners. This high level of rounding is used to humanize the technical data and create a "friendly" atmosphere.
- **Cards & Modules:** Use 16px radii.
- **Buttons & Inputs:** Use 12px radii.
- **Status Badges:** Use "Pill" (fully rounded) shapes to distinguish them from interactive buttons.
- **Icon Enclosures:** When icons are placed in containers, those containers should mirror the card's 16px radius for consistency.

## Components

- **Buttons:** Primary buttons use a solid #0EA5E9 fill with white text. Secondary buttons use a #F1F5F9 background with #1E293B text. Focus states should include a 2px offset ring in sky blue.
- **Inputs:** Fields should have a white background, 1px #E2E8F0 border, and 12px corner radius. Placeholder text must be in Slate (#64748B).
- **Cards:** The central container for all dashboard data. Use a 16px radius, a 1px #E2E8F0 border, and no shadow unless the card is "hovered" or "active."
- **Progress Bars (Bin Fill Levels):** Use a thick 8px track. The track is #F1F5F9, and the fill is the Primary Brand blue. If the level exceeds 90%, the fill color should dynamically switch to the Semantic Critical rose.
- **Icons:** Use 2px stroke-width outline icons. Ensure icons are consistently sized at 24px for desktop and 20px for mobile.
- **Data Chips:** Small, pill-shaped tags used to show bin types (e.g., "Recyclable", "Hazardous"). Use a light tint of the category color with a high-contrast text label.